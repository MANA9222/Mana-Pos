
document.querySelectorAll('button').forEach(btn => {
  btn.addEventListener('click', () => {
    alert('قريباً: ' + btn.textContent);
  });
});
